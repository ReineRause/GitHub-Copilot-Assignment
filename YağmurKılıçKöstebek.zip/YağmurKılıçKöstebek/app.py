from flask import Flask, request, jsonify, g, render_template
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "scores.db")

app = Flask(__name__)

# --- Database helpers -----------------------------------------------------

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
    return db


def init_db():
    """Create the `scores` table if it doesn't exist."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                score INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()


# Ensure DB initialization works across Flask versions
def initialize():
    init_db()

# Register initialization to run before the server starts if supported,
# otherwise register it for the older `before_first_request`, or call immediately.
if hasattr(app, "before_serving"):
    app.before_serving(initialize)
elif hasattr(app, "before_first_request"):
    app.before_first_request(initialize)
else:
    # Fallback for environments where neither decorator exists
    initialize()


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()


# --- Routes ---------------------------------------------------------------

@app.route("/")
def home():
    return render_template('index.html')


@app.route('/api/scores', methods=['POST'])
def save_score():
    """API endpoint to save a high score. Expects JSON {name: str, score: int}."""
    if not request.is_json:
        return jsonify({"error": "Expected application/json"}), 400
    data = request.get_json()

    name = data.get('name')
    score = data.get('score')

    if not name or not isinstance(name, str) or not name.strip():
        return jsonify({'error': 'Invalid name'}), 400
    try:
        score = int(score)
    except (TypeError, ValueError):
        return jsonify({'error': 'Invalid score'}), 400

    db = get_db()
    cur = db.cursor()
    cur.execute('INSERT INTO scores (name, score) VALUES (?, ?)', (name.strip(), score))
    db.commit()
    new_id = cur.lastrowid

    return jsonify({'id': new_id, 'name': name.strip(), 'score': score}), 201


if __name__ == '__main__':
    # Default: listen on 127.0.0.1:5000
    app.run(debug=True)
